#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "CharacterFacePreset.generated.h"

class USkeletalMesh;
class UGroomAsset;
class UGroomBindingAsset;

UCLASS(BlueprintType)
class FPS_API UCharacterFacePreset : public UDataAsset
{
	GENERATED_BODY()

public:

	// ��
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Face")
	TObjectPtr<USkeletalMesh> FaceMesh;

	// �Ӹ�
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Hair")
	TObjectPtr<UGroomAsset> HairGroom;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Hair")
	TObjectPtr<UGroomBindingAsset> HairBinding;

	// ����
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Eyebrows")
	TObjectPtr<UGroomAsset> EyebrowsGroom;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Eyebrows")
	TObjectPtr<UGroomBindingAsset> EyebrowsBinding;

	// �Ӵ���
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Eyelashes")
	TObjectPtr<UGroomAsset> EyelashesGroom;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Eyelashes")
	TObjectPtr<UGroomBindingAsset> EyelashesBinding;

	// ����
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Facial Hair")
	TObjectPtr<UGroomAsset> BeardGroom;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Facial Hair")
	TObjectPtr<UGroomBindingAsset> BeardBinding;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Facial Hair")
	TObjectPtr<UGroomAsset> MustacheGroom;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Facial Hair")
	TObjectPtr<UGroomBindingAsset> MustacheBinding;

	// �� ����
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Fuzz")
	TObjectPtr<UGroomAsset> FuzzGroom;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Fuzz")
	TObjectPtr<UGroomBindingAsset> FuzzBinding;
};