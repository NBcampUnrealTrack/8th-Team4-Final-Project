#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "CharacterCustomizationComponent.generated.h"

class UCharacterFacePreset;
class UMaterialInstanceDynamic;
class UGroomAsset;
class UGroomBindingAsset;
class UGroomComponent;


UENUM(BlueprintType)
enum class ECharacterPresetType : uint8
{
	Seo		UMETA(DisplayName = "Seo"),
	Custom	UMETA(DisplayName = "Custom"),
	Fab		UMETA(DisplayName = "Fab")
};


USTRUCT(BlueprintType)
struct FPS_API FCharacterHairPreset
{
	GENERATED_BODY()

	// ��� Groom
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Hair")
	TObjectPtr<UGroomAsset> Groom = nullptr;

	// Seo Face�� ���� Binding
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Hair")
	TObjectPtr<UGroomBindingAsset> SeoBinding = nullptr;

	// Custom Face�� Binding
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Hair")
	TObjectPtr<UGroomBindingAsset> CustomBinding = nullptr;

	// Fab Face�� Binding
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Hair")
	TObjectPtr<UGroomBindingAsset> FabBinding = nullptr;
};


USTRUCT(BlueprintType)
struct FPS_API FCharacterCustomizationData
{
	GENERATED_BODY()

	/*
	 * ���� ȣȯ��.
	 * ���� Face Mesh ��ü�� Mutable�� �����ϹǷ�
	 * �� Preset�� Groom �迭�� �⺻ ������ �����θ� ����Ѵ�.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Customization")
	TObjectPtr<UCharacterFacePreset> FacePreset = nullptr;

	UPROPERTY(
		EditAnywhere,
		BlueprintReadWrite,
		Category = "Customization",
		meta = (ClampMin = "0.0", ClampMax = "1.0")
	)
	float SkinValue = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Customization")
	FLinearColor OutfitColor = FLinearColor::White;
};


UCLASS(
	ClassGroup = (Customization),
	meta = (BlueprintSpawnableComponent)
)
class FPS_API UCharacterCustomizationComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UCharacterCustomizationComponent();

	// ���� FacePreset ȣȯ��.
	// Face Mesh / Hair�� ���⼭ �������� �ʴ´�.
	UFUNCTION(BlueprintCallable, Category = "Customization")
	void ApplyFacePreset(UCharacterFacePreset* Preset);

	UFUNCTION(BlueprintCallable, Category = "Customization")
	void ApplySkinValue(float NewValue);

	UFUNCTION(BlueprintCallable, Category = "Customization")
	void ApplyOutfitColor(const FLinearColor& NewColor);

	UFUNCTION(BlueprintCallable, Category = "Customization")
	void ApplyCustomization(
		const FCharacterCustomizationData& Customization
	);

	UFUNCTION(BlueprintCallable, Category = "Customization")
	void SetSkinValue(float NewValue);

	UFUNCTION(BlueprintCallable, Category = "Customization")
	void SetFacePreset(UCharacterFacePreset* NewPreset);

	UFUNCTION(BlueprintCallable, Category = "Customization")
	void SetOutfitColor(const FLinearColor& NewColor);


	// =========================
	// Hair
	// =========================

	UFUNCTION(BlueprintCallable, Category = "Customization|Hair")
	void SetHairStyle(int32 HairIndex);

	UFUNCTION(BlueprintCallable, Category = "Customization|Hair")
	void ApplyCurrentHair();

	/*
	 * Mutable�� BodyType�� �ݵ�� ���� ������ ������� �Ѵ�.
	 *
	 * Seo    -> Seo Binding
	 * Custom -> Custom Binding
	 * Fab    -> Fab Binding
	 */
	UFUNCTION(BlueprintCallable, Category = "Customization|Character")
	void SetCharacterPresetType(ECharacterPresetType NewPreset);


protected:
	virtual void BeginPlay() override;


	// =========================
	// ���� Customization
	// =========================

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Customization")
	FCharacterCustomizationData DefaultCustomization;

	UPROPERTY(BlueprintReadOnly, Category = "Customization")
	FCharacterCustomizationData CurrentCustomization;

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> FaceSkinMID = nullptr;

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> BodySkinMID = nullptr;

	UPROPERTY(
		EditAnywhere,
		BlueprintReadOnly,
		Category = "Customization|Outfit"
	)
	FName OutfitComponentName = TEXT("SkeletalMesh");

	UPROPERTY(Transient)
	TArray<TObjectPtr<UMaterialInstanceDynamic>> OutfitMIDs;


	// =========================
	// Hair Customization
	// =========================

	UPROPERTY(
		EditAnywhere,
		BlueprintReadOnly,
		Category = "Customization|Hair"
	)
	FName HairComponentName = TEXT("Hair");

	UPROPERTY(
		EditAnywhere,
		BlueprintReadOnly,
		Category = "Customization|Hair"
	)
	TArray<FCharacterHairPreset> HairPresets;

	UPROPERTY(
		EditAnywhere,
		BlueprintReadOnly,
		Category = "Customization|Character"
	)
	ECharacterPresetType CurrentCharacterPreset =
		ECharacterPresetType::Seo;

	UPROPERTY(
		EditAnywhere,
		BlueprintReadOnly,
		Category = "Customization|Hair"
	)
	int32 CurrentHairIndex = 0;

	UPROPERTY(Transient)
	TObjectPtr<UGroomComponent> HairComponent = nullptr;


private:
	void FindHairComponent();

	UGroomBindingAsset* GetBindingForCurrentCharacter(
		const FCharacterHairPreset& HairPreset
	) const;
};