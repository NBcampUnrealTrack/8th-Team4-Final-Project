#pragma once

#include "CoreMinimal.h"
#include "GameMode/State/BaseTeamMatchGameState.h"
#include "GameMode/Types/RoundTypes.h"
#include "BaseRoundGameState.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnRoundStateChangedSignature);

UCLASS()
class FPS_API ABaseRoundGameState : public ABaseTeamMatchGameState
{
	GENERATED_BODY()

public:
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Round")
	int32 GetCurrentRoundNumber() const;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Round")
	EGameFlowPhase GetGameFlowPhase() const;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Round")
	EGameTeam GetRoundWinner() const;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Round")
	ERoundEndReason GetRoundEndReason() const;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Round")
	ETeamRole GetTeamRole(EGameTeam Team) const;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Round")
	EGameTeam GetTeamForRole(ETeamRole TeamRole) const;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Round")
	float GetRoundTimeRemaining() const;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Round")
	bool IsRoundTimerFrozen() const;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Round")
	float GetPhaseTimeRemaining() const;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Loading")
	int32 GetLoadedPlayerCount() const;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Loading")
	int32 GetRequiredPlayerCount() const;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Loading")
	float GetLoadingProgress() const;

	UFUNCTION(BlueprintPure, Category = "Game Flow|Match")
	int32 GetMaxRounds() const;

	void InitializeRoundConfiguration(int32 NewMaxRounds);
	void SetRoundContext(const FRoundContext& RoundContext);
	void SetCurrentRoundNumber(int32 NewRoundNumber);
	void SetGameFlowPhase(EGameFlowPhase NewPhase, float PhaseDuration = 0.0f);
	void SetRoundTimer(float Duration);
	void FreezeRoundTimer();
	void ClearRoundTimer();
	void SetRoundResult(EGameTeam WinningTeam, ERoundEndReason EndReason);
	void ClearRoundResult();
	void SetTeamRoles(ETeamRole NewTeamARole, ETeamRole NewTeamBRole);
	void SetLoadingStatus(int32 NewLoadedPlayerCount, int32 NewRequiredPlayerCount);
	void ClearLoadingStatus();

protected:
	virtual void HandleMatchStateChanged() override;

	UFUNCTION()
	void OnRep_RoundState();

private:
	void BroadcastRoundStateChanged();

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Round")
	int32 CurrentRoundNumber = 0;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Round")
	EGameFlowPhase GameFlowPhase = EGameFlowPhase::WaitingForPlayers;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Round")
	EGameTeam RoundWinner = EGameTeam::None;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Round")
	ERoundEndReason RoundEndReason = ERoundEndReason::None;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Round")
	ETeamRole TeamARole = ETeamRole::Attackers;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Round")
	ETeamRole TeamBRole = ETeamRole::Defenders;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Round")
	float RoundEndServerTime = 0.0f;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Round")
	float FrozenRoundTimeRemaining = 0.0f;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Round")
	bool bRoundTimerFrozen = false;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Round")
	float PhaseEndServerTime = 0.0f;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Match")
	int32 MaxRounds = 0;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Loading")
	int32 LoadedPlayerCount = 0;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Loading")
	int32 RequiredPlayerCount = 0;

	UPROPERTY(ReplicatedUsing = OnRep_RoundState, VisibleInstanceOnly, Category = "Game Flow|Loading")
	float LoadingProgress = 0.0f;

public:
	UPROPERTY(BlueprintAssignable, Category = "Game Flow|Round")
	FOnRoundStateChangedSignature OnRoundStateChanged;
};
